import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import VehiclesPage from './components/VehiclesPage';
import ChargingStations from './components/ChargingStations';

function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
          <Navbar />
          <Routes>
            <Route path="/" element={<Hero />} />
            <Route path="/vehicles" element={<VehiclesPage />} />
            <Route path="/charging-stations" element={<ChargingStations />} />
          </Routes>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;