export interface Vehicle {
  id: string;
  name: string;
  brand: string;
  price: number;
  range: number;
  chargingTime: number;
  image: string;
  type: 'new' | 'used';
}

export interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  image: string;
}