import React from 'react';
import { MapPin, Battery, Info } from 'lucide-react';

const chargingStations = [
  {
    id: 1,
    name: "Tata Power Charging Station",
    location: "Mumbai, Maharashtra",
    type: "Fast Charging",
    available: true
  },
  {
    id: 2,
    name: "EESL Charging Hub",
    location: "Delhi NCR",
    type: "Fast Charging",
    available: true
  },
  {
    id: 3,
    name: "MG Motor Supercharger",
    location: "Bangalore, Karnataka",
    type: "Supercharger",
    available: true
  },
  {
    id: 4,
    name: "Ather Grid",
    location: "Chennai, Tamil Nadu",
    type: "Normal Charging",
    available: true
  }
];

export default function ChargingStations() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            EV Charging Stations in India
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Find convenient charging stations across India
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
            <div className="relative w-full h-[600px] bg-gray-200 dark:bg-gray-700">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15057.534307180755!2d72.5005!3d23.0334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e848aba5bd449%3A0x4fcedd11614f6516!2sAhmedabad%2C+Gujarat!5e0!3m2!1sen!2sin!4v1393684425269"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>

          <div className="space-y-4">
            {chargingStations.map(station => (
              <div
                key={station.id}
                className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                      <Battery className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      {station.name}
                    </h3>
                    <div className="mt-1 flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <MapPin className="w-4 h-4 mr-1" />
                      {station.location}
                    </div>
                    <div className="mt-2 flex items-center">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        station.available
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                          : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                      }`}>
                        {station.available ? 'Available' : 'Occupied'}
                      </span>
                      <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">
                        {station.type}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-blue-50 dark:bg-blue-900 p-4 rounded-lg">
              <div className="flex items-start">
                <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Looking for more stations?
                  </h4>
                  <p className="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Download our mobile app to access the complete network of charging stations across India.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}