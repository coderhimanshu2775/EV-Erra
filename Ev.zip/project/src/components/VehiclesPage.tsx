import React, { useState } from 'react';
import { Filter, Search } from 'lucide-react';
import VehicleCard from './VehicleCard';
import { Vehicle } from '../types';

const indianEvs: Vehicle[] = [
  {
    id: "tata-nexon-ev",
    name: "Nexon EV",
    brand: "Tata",
    price: 1499000,
    range: 465,
    chargingTime: 8.5,
    type: "new",
    image: "https://images.unsplash.com/photo-1697823185210-67f9c5a90a11?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "mg-zs-ev",
    name: "ZS EV",
    brand: "MG",
    price: 2499000,
    range: 461,
    chargingTime: 8,
    type: "new",
    image: "https://images.unsplash.com/photo-1697401307463-dd8155e6e75f?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "hyundai-kona",
    name: "Kona Electric",
    brand: "Hyundai",
    price: 2399000,
    range: 452,
    chargingTime: 7.5,
    type: "new",
    image: "https://images.unsplash.com/photo-1696938980863-96816b0cf817?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "mahindra-xuv400",
    name: "XUV400",
    brand: "Mahindra",
    price: 1599000,
    range: 456,
    chargingTime: 8,
    type: "new",
    image: "https://images.unsplash.com/photo-1696861890468-1e810e730f90?auto=format&fit=crop&q=80&w=800"
  }
];

export default function VehiclesPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 5000000]);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredVehicles = indianEvs.filter(vehicle => {
    const matchesSearch = vehicle.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vehicle.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPrice = vehicle.price >= priceRange[0] && vehicle.price <= priceRange[1];
    return matchesSearch && matchesPrice;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
            Electric Vehicles in India
          </h1>
          <div className="flex space-x-4 w-full md:w-auto">
            <div className="relative flex-1 md:flex-none">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search vehicles..."
                className="pl-10 pr-4 py-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
              <Filter className="h-5 w-5 mr-2" />
              Filters
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredVehicles.map(vehicle => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} />
          ))}
        </div>
      </div>
    </div>
  );
}