import React from 'react';
import { Link } from 'react-router-dom';
import { Sun, Moon, Car, Battery, MapPin, Newspaper, PhoneCall } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className="bg-white dark:bg-gray-900 fixed w-full z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Car className="h-8 w-8 text-green-600" />
              <span className="text-xl font-bold text-gray-900 dark:text-white">EVInfo</span>
            </Link>
          </div>

          <div className="hidden md:block">
            <div className="flex items-center space-x-4">
              <Link to="/vehicles" className="nav-link">
                <Car className="h-5 w-5" />
                <span>Vehicles</span>
              </Link>
              <Link to="/charging-stations" className="nav-link">
                <Battery className="h-5 w-5" />
                <span>Charging</span>
              </Link>
              <Link to="/news" className="nav-link">
                <Newspaper className="h-5 w-5" />
                <span>News</span>
              </Link>
              <Link to="/contact" className="nav-link">
                <PhoneCall className="h-5 w-5" />
                <span>Contact</span>
              </Link>
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {theme === 'dark' ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-gray-600" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}