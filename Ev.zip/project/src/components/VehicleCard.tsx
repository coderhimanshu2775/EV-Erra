import React from 'react';
import { Link } from 'react-router-dom';
import { Battery, Zap } from 'lucide-react';
import { Vehicle } from '../types';

interface VehicleCardProps {
  vehicle: Vehicle;
}

export default function VehicleCard({ vehicle }: VehicleCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <img 
        src={vehicle.image} 
        alt={vehicle.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{vehicle.name}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300">{vehicle.brand}</p>
        <div className="mt-4 space-y-2">
          <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
            <Battery className="h-4 w-4 mr-2" />
            <span>Range: {vehicle.range} km</span>
          </div>
          <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
            <Zap className="h-4 w-4 mr-2" />
            <span>Charging: {vehicle.chargingTime}h</span>
          </div>
        </div>
        <div className="mt-4">
          <p className="text-lg font-bold text-green-600">₹{vehicle.price.toLocaleString('en-IN')}</p>
        </div>
        <Link
          to={`/vehicles/${vehicle.id}`}
          className="mt-4 block w-full text-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}